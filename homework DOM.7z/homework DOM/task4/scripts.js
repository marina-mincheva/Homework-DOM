function Person(name, age, src) {
    var image = document.createElement("img");
    this.name = name;
    this.age = age;
    image.src = src;
    console.log(src);
}

Person.prototype.addToDiv = function () {
    for (var prop in this) {
        if (this.hasOwnProperty(prop)) {
            var x = document.createElement("div");
            var y = document.createTextNode(this[prop]);
            x.appendChild(y);
            var element = document.body;
            element.appendChild(x);
        }
    }
    console.log(element);
}

var marko = new Person("Marko", 25, "images/bird1.jpg");
marko.addToDiv();