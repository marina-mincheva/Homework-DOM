function create(a) {
    var parent1 = document.createElement(a);

    for (var i = 1; i < arguments.length; i++) {
        var child = arguments[i];
        if (typeof child === "string") {
            child = document.createElement(child);
            parent1.appendChild(child);
        } else if (Array.isArray(arguments[i])) {
            if (typeof arguments[i][0] === "string") {
                var parent2 = document.createElement(arguments[i][0]);
                parent1.appendChild(parent2);

                for (var j = 1; j < arguments[i].length; j++) {
                    if (!Array.isArray(arguments[i][j])) {
                        var child2 = arguments[i][j];
                        child2 = document.createElement(child2);
                        parent2.appendChild(child2);
                    } else if (Array.isArray(arguments[i][j])) {
                        var newArray = arguments[i][j];
                        var parent3 = document.createElement(newArray[0]);
                        parent2.appendChild(parent3);
                        for (var p = 1; p < newArray.length; p++) {
                            var child3 = newArray[p];
                            child3 = document.createElement(child3);
                            parent3.appendChild(child3);
                        }
                    }

                }
            } else if (Array.isArray(arguments[i][0])) {
                var arr = arguments[i][0];
                var parent4 = document.createElement(arr[0]);
                parent1.appendChild(parent4);
                for (var l = 1; l < arr.length; l++) {
                    if (typeof arr[l] === "string") {
                        var child4 = arr[l];
                        child4 = document.createElement(child4);
                        parent4.appendChild(child4);
                    } else if (Array.isArray(arr[l])) {
                        var nextArr = arr[l];
                        var parent5 = document.createElement(nextArr[0]);
                        parent1.appendChild(parent5);
                        for (var t = 1; t < nextArr.length; t++) {
                            var child5 = nextArr[t];
                            child5 = document.createElement(child5);
                            parent5.appendChild(child5);

                        }
                    }
                }
            }
        }

    } console.log(parent1);
}
var u = create("div", "p", "span", ["h1", "a", "p"], "h2", ["p",["div", "p"], ["h2", "span"]]);
// else if (Array.isArray(arguments[i])) {

//             var parent2 = document.createElement(arguments[i][0]);
//             parent1.appendChild(parent2);

//             for (var j = 1; j < arguments[i].length; j++) {  
//                 var child2 = arguments[i][j];
//                 child2 = document.createElement(child2);
//                 parent2.appendChild(child2);
//             }
//         }