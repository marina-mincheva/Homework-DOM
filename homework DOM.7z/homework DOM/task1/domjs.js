 function create(element) {
    var parent = document.createElement(element);
    console.log(parent);
    for (var index = 1; index < arguments.length; index++) {
        var child = arguments[index];
        if (typeof child == "string") {
            child = document.createElement(child);
            console.log(parent.appendChild(child));
            document.body.appendChild(parent);
        } else {
            return "Put a string elements";
        }
    }
}

var elements = create("p", "a", "img", "a");