function ShoppingCart() {
    this.div = document.createElement("div");
    this.textDiv = document.createTextNode("Empty");
    this.div.appendChild(this.textDiv);
    this.div.setAttribute("id", "firstDiv");
    this.div.style.border = ("2px solid black");
    this.div.style.width = ("300px");
    this.div.style.height = ("300px");
    document.body.appendChild(this.div);
    this.array = new Array(10);
}

ShoppingCart.prototype.addProduct = function (obj) {
    this.textDiv.nodeValue = "";
    var p = document.createElement("p");

    for (var i = 0; i < this.array.length; i++) {
        if (this.array[i] === undefined) {
            this.array.splice(i, 1, obj);
            break;
        }
    }
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            if (prop == "image") {
                var pic = document.createElement("img");
                pic.setAttribute("src", obj.image);
                pic.style.width = "30px";
                pic.style.height = "30px";
                p.appendChild(pic);
            } else {
                p.innerHTML += obj[prop] + ": ";
            }
        }
    }
    document.getElementById("firstDiv").appendChild(p);
    console.log(this.array);
}
ShoppingCart.prototype.removeProduct = function (index) {
    // for (var i = 0; i < this.array.length; i++) {
        this.array.splice(index, 1, undefined);
        var child = document.getElementById("firstDiv").childNodes[index+1];
        child.parentNode.removeChild(child);
        console.log(this.array);
    // }
}

var cart = new ShoppingCart();
cart.addProduct({ name: "Malini", guantity: "1kg", image: "images/malini.jpg" });
cart.addProduct({ name: "Kypini", guantity: "2kg", image: "images/kypini.jpg" });
cart.addProduct({ name: "Praskovi", guantity: "8kg", image: "images/praskovi.jpg" });
cart.removeProduct(0);
