function myFunction () {
     var x = document.getElementById("frm");
     var text = "";
     var u = "";
     var elem = document.body;
     for (var i = 0; i < x.length; i++) {
         var newP = document.createElement("p");
         text = x.elements[i].value + '\n';
         var innerText = document.createTextNode(text);
         newP.appendChild(innerText);
         elem.appendChild(newP);
     }
 }
  